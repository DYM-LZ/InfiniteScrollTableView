//
//  ViewController.m
//  InfiniteScrollTableView
//
//  Created by LZ on 16/2/2.
//  Copyright © 2016年 lizhen. All rights reserved.
//
#import "ViewController.h"
#import "UIColor+Ext.h"
#import "InfiniteScrollTableView.h"
@interface ViewController () <InfiniteScrollTableViewDataSource, InfiniteScrollTableViewDelegate, UIScrollViewDelegate>

@property (nonatomic, weak) InfiniteScrollTableView *tableView;

@property (nonatomic, copy) NSArray *data;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    InfiniteScrollTableView *tableView = [[InfiniteScrollTableView alloc] initWithFrame:self.view.bounds];
    _tableView = tableView;
    [self.view addSubview:tableView];
    tableView.delegate = self;
    tableView.dataSource = self;

    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:@"testScroll" forState:UIControlStateNormal];
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(testScroll) forControlEvents:UIControlEventTouchUpInside];
    button.frame = CGRectMake((self.view.bounds.size.width - 200) * 0.5, 44, 200, 60);
    [self.view addSubview:button];

    self.data = @[@"沉鱼落雁", @"闭月羞花", @"什么玩意", @"或的咖啡", @"附加速度附近", @"大家ufioe", @"或订货会回复", @"勇敢的心", @"北京北京", @"飞得更高", @"汪峰", @"musicKing", @"1", @"2", @"音3", @"音4", @"音5", @"音6", @"音7", @"音8", @"音9", @"音10", @"音11", @"音12", @"音13", @"音14", @"音15", @"音16", @"音17", @"音18", @"音19", @"音20", @"音21"];
//    self.data = @[@"沉鱼落雁"];
}

- (void)testScroll {
    NSInteger row = arc4random() % 20;
//    BOOL animated = arc4random() % 2;
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row inSection:0];
    [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionNone animated:YES];
//    NSLog(@"row = %zd, title = %@", row, self.data[row]);
    NSLog(@"%zd", row);

//    [self.tableView setContentOffset:CGPointMake(0, 1500) animated:NO];
}

#pragma mark - InfiniteScrollTableViewDataSource
//- (NSInteger)numberOfSectionsInInfiniteScrollTableView:(InfiniteScrollTableView *)infiniteScrollTableView {
//    return 1;
//}

- (NSInteger)infiniteScrollTableView:(InfiniteScrollTableView *)infiniteScrollTableView numberOfRowsInSection:(NSInteger)section {
    return 20;
}

- (UITableViewCell *)infiniteScrollTableView:(InfiniteScrollTableView *)infiniteScrollTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *ID = @"cell";
    UITableViewCell *cell = [infiniteScrollTableView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
    }
    NSString *string = @(indexPath.row).stringValue;
    cell.textLabel.text = string;
    cell.backgroundColor = [UIColor randomColor];
//    NSLog(@"%p", cell);
    return cell;
}

#pragma mark - InfiniteScrollTableViewDelegate
- (CGFloat)infiniteScrollTableView:(InfiniteScrollTableView *)infiniteScrollTableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    CGFloat height = 44;
    if (indexPath.row % self.data.count == 0) {
        height = 84;
    } else if (indexPath.row % self.data.count == 1) {
        height = 54;
    } else if (indexPath.row % self.data.count == 2) {
        height = 74;
    } else if (indexPath.row % self.data.count == 3) {
        height = 44;
    } else if (indexPath.row % self.data.count == 4) {
        height = 64;
    } else if (indexPath.row % self.data.count == 5) {
        height = 54;
    }
    return height;
}

- (void)infiniteScrollTableView:(InfiniteScrollTableView *)infiniteScrollTableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {

}
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
