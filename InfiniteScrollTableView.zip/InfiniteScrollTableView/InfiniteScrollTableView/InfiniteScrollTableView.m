//
//  InfiniteScrollTableView.m
//  InfiniteScrollTableView
//
//  Created by LZ on 16/2/2.
//  Copyright © 2016年 lizhen. All rights reserved.
//

#import "InfiniteScrollTableView.h"

@interface InfiniteScrollTableView ()
@property (nonatomic, strong) NSMutableArray *usingArray;
@property (nonatomic, strong) NSMutableArray *reuseArray;
@property (nonatomic) NSInteger itemsCount;
@property (nonatomic, strong) NSMutableArray *usingIndexPaths;
@property (nonatomic) CGFloat lastOffsetY;
@end

@implementation InfiniteScrollTableView
@dynamic delegate;
- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.showsHorizontalScrollIndicator = NO;
        self.showsVerticalScrollIndicator = NO;
        self.backgroundColor = [UIColor yellowColor];
    }
    return self;
}
- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    if (self = [super initWithCoder:aDecoder]) {
        self.showsHorizontalScrollIndicator = NO;
        self.showsVerticalScrollIndicator = NO;
    }
    return self;
}

- (NSMutableArray *)usingIndexPaths {
    if (_usingIndexPaths == nil) {
        _usingIndexPaths = [NSMutableArray array];
    }
    return _usingIndexPaths;
}
- (NSMutableArray *)usingArray {
    if (_usingArray == nil) {
        _usingArray = [NSMutableArray array];
    }
    return _usingArray;
}

- (NSMutableArray *)reuseArray {
    if (_reuseArray == nil) {
        _reuseArray = [NSMutableArray array];
    }
    return _reuseArray;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    if (self.usingArray.count <= 0) {
        [self setUpCells];
    }

    [self scroll];
}

- (void)scroll {

    CGFloat offsetY = self.contentOffset.y;
    CGFloat bottom = CGRectGetMaxY([self.usingArray.lastObject frame]);
    CGFloat top = CGRectGetMinY([self.usingArray.firstObject frame]);
    if (self.lastOffsetY < offsetY) {//上滑

        while (bottom < offsetY + self.bounds.size.height) {
            UITableViewCell *firstCell = self.usingArray.firstObject;
            UITableViewCell *lastCell = self.usingArray.lastObject;
            CGFloat firstCellMaxY = CGRectGetMaxY(firstCell.frame);
            CGFloat lastCellMinY = lastCell.frame.origin.y;

            if (firstCellMaxY < offsetY) {//移除最上边的cell
                [self.usingArray removeObject:firstCell];
                [self.usingIndexPaths removeObjectAtIndex:0];
                [self.reuseArray addObject:firstCell];
                [firstCell removeFromSuperview];
            }

            if (lastCellMinY < offsetY + self.bounds.size.height) {//向下添加cell
                NSIndexPath *indexPath = self.usingIndexPaths.lastObject;
                NSInteger row = (indexPath.row + 1) % self.itemsCount;
                NSIndexPath *newIndexPath = [NSIndexPath indexPathForRow:row inSection:0];
                CGFloat rowHeight = self.rowHeight > 0 ? self.rowHeight : 44;
                if ([self.delegate respondsToSelector:@selector(infiniteScrollTableView:heightForRowAtIndexPath:)]) {
                    rowHeight = [self.delegate infiniteScrollTableView:self heightForRowAtIndexPath:newIndexPath];
                }

                if ([self.dataSource respondsToSelector:@selector(infiniteScrollTableView:cellForRowAtIndexPath:)]) {

                    UITableViewCell *cell = [self.dataSource infiniteScrollTableView:self cellForRowAtIndexPath:newIndexPath];
                    cell.frame = CGRectMake(0, CGRectGetMaxY(lastCell.frame), self.bounds.size.width, rowHeight);
                    [self addSubview:cell];
                    [self.usingIndexPaths addObject:newIndexPath];
                    [self.usingArray addObject:cell];
                    bottom += rowHeight;
                }
            }
        }


        if (self.contentOffset.y > self.contentSize.height / 3.0f * 2.0f) {
            [self resetContentOffset];
        }
    } else {//下滑

        while (top >= offsetY) {
            UITableViewCell *firstCell = self.usingArray.firstObject;
            UITableViewCell *lastCell = self.usingArray.lastObject;

            CGFloat firstCellMaxY = CGRectGetMaxY(firstCell.frame);
            CGFloat lastCellMinY = lastCell.frame.origin.y;
            if (lastCellMinY > offsetY + self.bounds.size.height) {//移除最下边的cell
                [self.usingArray removeObject:lastCell];
                [self.usingIndexPaths removeLastObject];
                [self.reuseArray addObject:lastCell];
            }
            if (firstCellMaxY > offsetY) {//向上添加cell
                NSIndexPath *indexPath = self.usingIndexPaths.firstObject;
                NSInteger row = indexPath.row - 1;
                if (row >= 0) {
                    row = (indexPath.row - 1) % self.itemsCount;
                } else {
                    row = (self.itemsCount + (indexPath.row - 1)) % self.itemsCount;
                }
                NSIndexPath *newIndexPath = [NSIndexPath indexPathForRow:row inSection:0];
                CGFloat rowHeight = self.rowHeight > 0 ? self.rowHeight : 44;
                if ([self.delegate respondsToSelector:@selector(infiniteScrollTableView:heightForRowAtIndexPath:)]) {
                    rowHeight = [self.delegate infiniteScrollTableView:self heightForRowAtIndexPath:newIndexPath];
                }

                if ([self.dataSource respondsToSelector:@selector(infiniteScrollTableView:cellForRowAtIndexPath:)]) {

                    UITableViewCell *cell = [self.dataSource infiniteScrollTableView:self cellForRowAtIndexPath:newIndexPath];
                    cell.frame = CGRectMake(0, CGRectGetMinY(firstCell.frame) - rowHeight, self.bounds.size.width, rowHeight);
                    [self addSubview:cell];
                    [self.usingIndexPaths insertObject:newIndexPath atIndex:0];
                    [self.usingArray insertObject:cell atIndex:0];
                    top -= rowHeight;
                }
            }

        }
        if (self.contentOffset.y < 0) {
            [self resetContentOffset];
        }
    }

    self.lastOffsetY = offsetY;
}


- (void)scrollToRowAtIndexPath:(NSIndexPath *)indexPath atScrollPosition:(UITableViewScrollPosition)scrollPosition animated:(BOOL)animated {

    for (NSInteger i = 0; i < self.usingIndexPaths.count; i++) {
        NSIndexPath *tempIndexPath = self.usingIndexPaths[i];
        if (tempIndexPath.row == indexPath.row) {
            UITableViewCell *totalCell = self.usingArray[i];
            [self setContentOffset:CGPointMake(0, totalCell.frame.origin.y) animated:animated];
            return;
        }
    }

    NSIndexPath *topIndexPath = self.usingIndexPaths.firstObject;
    UITableViewCell *topCell = self.usingArray.firstObject;
    UITableViewCell *bottomCell = self.usingArray.lastObject;

    NSInteger rowDiff = topIndexPath.row - indexPath.row;

    NSInteger rowNumber = topIndexPath.row;
    CGFloat bottomOffsetY = CGRectGetMaxY(bottomCell.frame);
    if (rowDiff == 0) {
        [self setContentOffset:CGPointMake(0, topCell.frame.origin.y) animated:animated];
    } else if (rowDiff > 0) {
        while (topIndexPath.row < indexPath.row) {
            rowNumber ++;
            if ([self.delegate respondsToSelector:@selector(infiniteScrollTableView:heightForRowAtIndexPath:)]) {
               CGFloat rowHeight = [self.delegate infiniteScrollTableView:self heightForRowAtIndexPath:[NSIndexPath indexPathForRow:rowNumber inSection:0]];
                bottomOffsetY += rowHeight;
            }
        }
        [self setContentOffset:CGPointMake(0, bottomOffsetY) animated:animated];
    } else {
        while (topIndexPath.row >= indexPath.row) {
            if ([self.delegate respondsToSelector:@selector(infiniteScrollTableView:heightForRowAtIndexPath:)]) {
                CGFloat rowHeight = [self.delegate infiniteScrollTableView:self heightForRowAtIndexPath:[NSIndexPath indexPathForRow:rowNumber inSection:0]];
                bottomOffsetY -= rowHeight;
            }
            rowNumber --;
        }
        [self setContentOffset:CGPointMake(0, bottomOffsetY) animated:animated];
    }

}

- (void)didMoveToSuperview {
    [super didMoveToSuperview];
    [self setUpContentSize];
}

- (void)resetContentOffset {
    UITableViewCell *firstCell = self.usingArray[0];
    CGFloat topMargin = CGRectGetMinY(firstCell.frame) - self.contentOffset.y;
    [self setContentOffset:CGPointMake(0, self.contentSize.height / 3.0f)];
    self.lastOffsetY = self.contentSize.height / 3.0f;
    CGFloat bottomOffsetY = self.contentOffset.y + topMargin;
    for (UITableViewCell *cell in self.usingArray) {
        cell.frame = CGRectMake(0, bottomOffsetY, cell.bounds.size.width, cell.bounds.size.height);
        bottomOffsetY = CGRectGetMaxY(cell.frame);
    }
}

- (void)setUpContentSize {
    CGFloat contentSizeHeight = 0;

    if ([self.dataSource respondsToSelector:@selector(infiniteScrollTableView:numberOfRowsInSection:)]) {
        self.itemsCount = [self.dataSource infiniteScrollTableView:self numberOfRowsInSection:0];

        for (NSInteger j = 0; j < self.itemsCount; j++) {
            CGFloat rowHeight = self.rowHeight > 0 ? self.rowHeight : 44;

            if ([self.delegate respondsToSelector:@selector(infiniteScrollTableView:heightForRowAtIndexPath:)]) {
                NSIndexPath *indexPath = [NSIndexPath indexPathForRow:j inSection:0];
                rowHeight = [self.delegate infiniteScrollTableView:self heightForRowAtIndexPath:indexPath];
            }
            contentSizeHeight += rowHeight;
            if (contentSizeHeight > self.bounds.size.height) {
                break;
            }
        }
    }
    if (contentSizeHeight < self.bounds.size.height) {
        contentSizeHeight = self.bounds.size.height;
    }

    [self setContentSize:CGSizeMake(0, contentSizeHeight * 3)];
    [self setContentOffset:CGPointMake(0, contentSizeHeight)];
    self.lastOffsetY = contentSizeHeight;
}

- (BOOL)isInScreenWithFrame:(CGRect)frame {
    CGFloat maxY = CGRectGetMaxY(frame);
    CGFloat minY = frame.origin.y;
    CGFloat offsetY = self.contentOffset.y;
    return maxY > offsetY && minY < (offsetY + self.bounds.size.height);
}

- (void)setUpCells {
    CGFloat currentBottom = self.bounds.size.height;
    CGFloat rowHeight = 0;
    while (currentBottom  < self.bounds.size.height * 2) {
        if ([self.dataSource respondsToSelector:@selector(infiniteScrollTableView:numberOfRowsInSection:)]) {
            self.itemsCount = [self.dataSource infiniteScrollTableView:self numberOfRowsInSection:0];

            for (NSInteger j = 0; j < self.itemsCount; j++) {
                NSIndexPath *indexPath = [NSIndexPath indexPathForRow:j inSection:0];
                UITableViewCell *cell = nil;
                if ([self.dataSource respondsToSelector:@selector(infiniteScrollTableView:cellForRowAtIndexPath:)]) {
                    cell =[self.dataSource infiniteScrollTableView:self cellForRowAtIndexPath:indexPath];
                }
                if (cell) {
                    [self.usingArray addObject:cell];
                }

                rowHeight = self.rowHeight > 0 ? self.rowHeight : 44;
                if ([self.delegate respondsToSelector:@selector(infiniteScrollTableView:heightForRowAtIndexPath:)]) {
                    rowHeight = [self.delegate infiniteScrollTableView:self heightForRowAtIndexPath:indexPath];
                }
                cell.frame = CGRectMake(0, currentBottom, self.bounds.size.width, rowHeight);
                [self.usingIndexPaths addObject:indexPath];
                [self addSubview:cell];
                currentBottom += rowHeight;

                if (currentBottom - rowHeight > self.bounds.size.height * 2) {
                    break;
                }
            }
        }

    } ;
}

- (UITableViewCell *)dequeueReusableCellWithIdentifier:(NSString *)reuseIdentifier {
    if (self.reuseArray.count <= 0) {
        return nil;
    }
    UITableViewCell *cell = nil;
    for (UITableViewCell *tempCell in self.reuseArray) {
        if ([tempCell.reuseIdentifier isEqualToString:reuseIdentifier]) {
            cell = tempCell;
            [self.reuseArray removeObject:cell];
            break;
        }
    }
    return cell;
}

- (void)reloadData {
    [self.usingIndexPaths removeAllObjects];
    for (UITableViewCell *cell in self.usingArray.copy) {
        [cell removeFromSuperview];
        [self.reuseArray addObject:cell];
        [self.usingArray removeObject:cell];
    }
}
@end
