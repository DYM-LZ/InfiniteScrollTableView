//
//  InfiniteScrollTableView.h
//  InfiniteScrollTableView
//
//  Created by LZ on 16/2/2.
//  Copyright © 2016年 lizhen. All rights reserved.
//

#import <UIKit/UIKit.h>

@class InfiniteScrollTableView;
@protocol InfiniteScrollTableViewDataSource <NSObject>

@required
- (NSInteger)infiniteScrollTableView:(InfiniteScrollTableView *)infiniteScrollTableView numberOfRowsInSection:(NSInteger)section;
- (UITableViewCell *)infiniteScrollTableView:(InfiniteScrollTableView *)infiniteScrollTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
@optional
//- (NSInteger)numberOfSectionsInInfiniteScrollTableView:(InfiniteScrollTableView *)infiniteScrollTableView;

@end

@protocol InfiniteScrollTableViewDelegate <NSObject, UIScrollViewDelegate>
@optional
- (CGFloat)infiniteScrollTableView:(InfiniteScrollTableView *)infiniteScrollTableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
- (void)infiniteScrollTableView:(InfiniteScrollTableView *)infiniteScrollTableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath;
@end

@interface InfiniteScrollTableView : UIScrollView

@property (nonatomic) CGFloat rowHeight;
@property (nonatomic, weak) id <InfiniteScrollTableViewDataSource> dataSource;
@property (nonatomic, weak) id <InfiniteScrollTableViewDelegate> delegate;

- (UITableViewCell *)dequeueReusableCellWithIdentifier:(NSString *)identifier;
- (void)scrollToRowAtIndexPath:(NSIndexPath *)indexPath atScrollPosition:(UITableViewScrollPosition)scrollPosition animated:(BOOL)animated;
@end
