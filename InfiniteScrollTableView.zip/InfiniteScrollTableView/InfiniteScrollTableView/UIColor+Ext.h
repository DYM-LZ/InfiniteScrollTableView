//
//  UIColor+Ext.h
//  Dayima
//
//  Created by sunzj on 15/6/26.
//
//

#import <UIKit/UIKit.h>

@interface UIColor (Ext)

+ (UIColor *)randomColor;

@end
